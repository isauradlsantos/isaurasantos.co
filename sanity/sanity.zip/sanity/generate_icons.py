#!/usr/bin/env python3
"""Generate the sanity toolbar icons as plain PNGs."""

from __future__ import annotations

import math
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "icons"
INK = (22, 24, 45, 255)  # #16182d
PAPER = (247, 245, 240, 255)  # #f7f5f0


def chunk(tag: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def encode_png(size: int, pixels: list[tuple[int, int, int, int]]) -> bytes:
    raw = b""
    for y in range(size):
        raw += b"\x00"
        for x in range(size):
            raw += bytes(pixels[y * size + x])
    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def rounded_rect(px: float, py: float, size: int, radius: float) -> bool:
    x = px + 0.5
    y = py + 0.5
    left, top, right, bottom = 0.0, 0.0, float(size), float(size)
    if left + radius <= x <= right - radius and top <= y <= bottom:
        return True
    if top + radius <= y <= bottom - radius and left <= x <= right:
        return True
    corners = [
        (left + radius, top + radius),
        (right - radius, top + radius),
        (left + radius, bottom - radius),
        (right - radius, bottom - radius),
    ]
    return any((x - cx) ** 2 + (y - cy) ** 2 <= radius**2 for cx, cy in corners)


def in_asterisk(px: float, py: float, size: int) -> bool:
    """Six-pointed mark matching the ✻ wordmark."""
    cx = size / 2
    cy = size / 2
    x = px + 0.5 - cx
    y = py + 0.5 - cy
    r = math.hypot(x, y)
    outer = size * 0.28
    hub = size * 0.08
    half_w = size * 0.05
    if r > outer:
        return False
    if r <= hub:
        return True
    angle = math.atan2(y, x)
    for i in range(6):
        a = i * math.pi / 3
        da = abs(((angle - a + math.pi) % (2 * math.pi)) - math.pi)
        width = half_w * (1.2 - 0.5 * (r / outer))
        if da < (width / max(r, 1e-6)):
            return True
    return False


def render(size: int) -> bytes:
    radius = size * 0.22
    pixels = []
    for y in range(size):
        for x in range(size):
            if rounded_rect(x, y, size, radius):
                pixels.append(PAPER if in_asterisk(x, y, size) else INK)
            else:
                pixels.append((0, 0, 0, 0))
    return encode_png(size, pixels)


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    for size in (16, 32, 48, 128):
        (ROOT / f"icon{size}.png").write_bytes(render(size))
    print("wrote icons", ", ".join(f"icon{s}.png" for s in (16, 32, 48, 128)))


if __name__ == "__main__":
    main()
