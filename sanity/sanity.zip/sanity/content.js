(() => {
  if (!sanityIsLinkedInHost(location.hostname)) return;

  const HOST_ID = "sanity-host";
  const STYLE = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .layer {
      position: fixed;
      inset: 0;
      pointer-events: none;
      font-family: Georgia, "Iowan Old Style", "Times New Roman", serif;
      color: #16182d;
      -webkit-font-smoothing: antialiased;
    }
    .cover, .sheet, .chip {
      pointer-events: auto;
    }
    .cover {
      position: absolute;
      inset: 0;
      background: #f7f5f0;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }
    .aurora {
      position: absolute;
      border-radius: 999px;
      filter: blur(80px);
      pointer-events: none;
    }
    .a1 {
      width: 620px;
      height: 620px;
      right: -160px;
      top: -180px;
      background: radial-gradient(circle at 40% 45%, #ffcda6 0%, #ffb37c 45%, rgba(255, 179, 124, 0) 72%);
    }
    .a2 {
      width: 480px;
      height: 480px;
      right: 200px;
      top: -60px;
      background: radial-gradient(circle at 50% 50%, #b9c8ff 0%, rgba(185, 200, 255, 0) 70%);
      opacity: 0.9;
    }
    .a3 {
      width: 560px;
      height: 560px;
      left: -220px;
      bottom: -260px;
      background: radial-gradient(circle at 50% 50%, #e9ddff 0%, rgba(233, 221, 255, 0) 70%);
    }
    .top {
      position: relative;
      z-index: 2;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 26px 40px 0;
    }
    .brand {
      display: inline-flex;
      align-items: baseline;
      gap: 8px;
      font-size: 19px;
      letter-spacing: 0.01em;
      color: #16182d;
    }
    .brand .mark { font-size: 14px; }
    .meta {
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 11px;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: #7b7d90;
    }
    .top .clock {
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 12px;
      letter-spacing: 0.1em;
      font-variant-numeric: tabular-nums;
      color: #16182d;
    }
    .sheet {
      position: relative;
      z-index: 2;
      width: min(600px, calc(100% - 48px));
      margin: auto;
      padding: 0 0 72px;
    }
    h1 {
      font-size: 46px;
      line-height: 1.06;
      font-weight: 400;
      letter-spacing: -0.015em;
      margin: 0 0 16px;
    }
    h1 .it { font-style: italic; }
    .lede {
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 15px;
      line-height: 1.6;
      color: #5f6173;
      margin: 0 0 36px;
      max-width: 34em;
    }
    .lede .line { display: block; }
    .lede .line:first-child { color: #16182d; }
    .intents {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-bottom: 32px;
    }
    .intent {
      appearance: none;
      text-align: left;
      cursor: pointer;
      font: inherit;
      color: inherit;
      background: rgba(255, 255, 255, 0.55);
      border: 1px solid rgba(22, 24, 45, 0.12);
      border-radius: 18px;
      padding: 18px;
      transition: border-color 0.15s ease, background 0.2s ease, color 0.2s ease;
    }
    .intent:hover { border-color: #16182d; }
    .intent.is-on {
      background: #16182d;
      border-color: #16182d;
      color: #f7f5f0;
    }
    .intent.is-danger {
      border-color: rgba(139, 46, 26, 0.4);
      background: rgba(255, 255, 255, 0.55);
    }
    .intent.is-danger:hover { border-color: #8b2e1a; }
    .intent.is-danger.is-on {
      background: #8b2e1a;
      border-color: #8b2e1a;
      color: #fff6f0;
    }
    .intent.is-danger .label { color: #8b2e1a; }
    .intent.is-danger.is-on .label { color: inherit; }
    .intent.is-danger .hint { color: #8b2e1a; opacity: 0.75; }
    .intent.is-danger.is-on .hint { color: inherit; opacity: 0.75; }
    .intent .label {
      display: block;
      font-size: 19px;
      letter-spacing: -0.01em;
    }
    .intent .warn {
      display: inline-block;
      margin-right: 8px;
      font-style: normal;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 14px;
      letter-spacing: 0;
    }
    .intent .hint {
      display: block;
      margin-top: 6px;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 12.5px;
      line-height: 1.45;
      opacity: 0.66;
    }
    .log-line {
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 13px;
      color: #5f6173;
      margin: 0 0 18px;
      padding: 12px 14px;
      border-radius: 14px;
      background: rgba(255, 255, 255, 0.55);
      border: 1px solid rgba(22, 24, 45, 0.1);
    }
    .secondary {
      appearance: none;
      cursor: pointer;
      background: transparent;
      color: #16182d;
      border: 1px solid rgba(22, 24, 45, 0.28);
      border-radius: 999px;
      padding: 12px 22px;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 14px;
    }
    .secondary:hover { border-color: #16182d; }
    .log-panel {
      max-height: 280px;
      overflow: auto;
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin: 0 0 28px;
    }
    .log-panel .item {
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 13px;
      padding: 12px 14px;
      border-radius: 14px;
      background: rgba(255, 255, 255, 0.7);
      border: 1px solid rgba(22, 24, 45, 0.1);
    }
    .log-panel .item.is-danger {
      background: rgba(255, 255, 255, 0.7);
      border-color: rgba(139, 46, 26, 0.22);
    }
    .log-panel .why {
      font-family: Georgia, "Iowan Old Style", serif;
      font-size: 15px;
      color: #16182d;
    }
    .log-panel .meta-line {
      margin-top: 4px;
      color: #7b7d90;
      font-size: 12px;
      font-variant-numeric: tabular-nums;
    }
    .log-panel .stats {
      margin-top: 2px;
      color: #5f6173;
      font-size: 12px;
      font-variant-numeric: tabular-nums;
    }
    .chip.is-danger { background: #8b2e1a; }
    .chip.is-danger .dot { background: #ffb37c; }
    .chip.is-danger .clock { color: #ffd7c2; }
    .when {
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 11px;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: #7b7d90;
      margin-bottom: 12px;
    }
    .durations {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-bottom: 36px;
    }
    .duration {
      appearance: none;
      cursor: pointer;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 13.5px;
      color: #16182d;
      background: transparent;
      border: 1px solid rgba(22, 24, 45, 0.28);
      border-radius: 999px;
      padding: 10px 22px;
      transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease;
    }
    .duration:hover {
      background: #16182d;
      border-color: #16182d;
      color: #f7f5f0;
    }
    .duration.is-usual { border-color: #16182d; }
    .duration:disabled {
      opacity: 0.3;
      cursor: not-allowed;
    }
    .actions {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 18px;
    }
    .primary {
      appearance: none;
      cursor: pointer;
      border: 0;
      border-radius: 999px;
      background: #16182d;
      color: #f7f5f0;
      padding: 14px 28px;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 14px;
    }
    .primary:hover { background: #262a4d; }
    .quiet {
      appearance: none;
      background: none;
      border: 0;
      padding: 0;
      color: #7b7d90;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 13px;
      cursor: pointer;
      text-decoration: underline;
      text-underline-offset: 3px;
    }
    .quiet:hover { color: #16182d; }
    .quote-block {
      width: 100%;
      max-width: none;
      margin: 0 0 40px;
    }
    .quote-text {
      margin: 0 0 22px;
      font-size: clamp(34px, 5vw, 56px);
      line-height: 1.2;
      font-weight: 400;
      letter-spacing: -0.025em;
      color: #16182d;
      max-width: 16em;
    }
    .quote-author {
      margin: 0;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 14px;
      letter-spacing: 0.06em;
      color: #7b7d90;
    }
    .quote-author::before {
      content: "— ";
    }
    .sheet.is-quote {
      width: min(860px, calc(100% - 64px));
      min-height: calc(100% - 88px);
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 32px 0 110px;
    }
    .sheet.is-quote .actions {
      gap: 16px;
    }
    .sheet.is-quote .primary {
      padding: 15px 32px;
      font-size: 15px;
    }
    .credit {
      position: absolute;
      z-index: 2;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      margin: 0;
      padding: 0 40px 28px;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 12px;
      color: #7b7d90;
    }
    .credit a {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      border-radius: 4px;
      background: #0a66c2;
      color: #fff;
    }
    .credit a:hover { background: #004182; }
    .credit svg { display: block; }
    .credit .settings-btn {
      appearance: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      margin-left: 14px;
      padding: 0;
      border: 0;
      border-radius: 4px;
      background: transparent;
      color: #7b7d90;
      cursor: pointer;
    }
    .credit .settings-btn:hover { color: #16182d; }
    .settings-sheet label {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
      margin: 0 0 14px;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 14px;
      color: #5f6173;
    }
    .settings-sheet select {
      font: inherit;
      font-size: 13px;
      background: rgba(255, 255, 255, 0.75);
      border: 1px solid rgba(22, 24, 45, 0.18);
      border-radius: 999px;
      color: #16182d;
      padding: 6px 12px;
    }
    .settings-sheet .stepper-block {
      margin-top: 8px;
      padding-top: 16px;
      border-top: 1px solid rgba(22, 24, 45, 0.1);
    }
    .settings-sheet .stepper {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-top: 12px;
      padding: 8px;
      border-radius: 999px;
      border: 1px solid rgba(22, 24, 45, 0.12);
      background: rgba(255, 255, 255, 0.7);
    }
    .settings-sheet .stepper-btn {
      appearance: none;
      width: 36px;
      height: 36px;
      border: 0;
      border-radius: 999px;
      background: #16182d;
      color: #f7f5f0;
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
    }
    .settings-sheet .stepper-btn:hover { background: #262a4d; }
    .settings-sheet .stepper-value {
      margin: 0;
      min-width: 5em;
      text-align: center;
      font-family: Georgia, "Iowan Old Style", serif;
      font-size: 18px;
      color: #16182d;
    }
    .settings-sheet .stepper-hint {
      margin: 6px 0 0;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 12px;
      color: #7b7d90;
    }
    .row {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      align-items: center;
    }
    .chip {
      position: fixed;
      right: 24px;
      bottom: 24px;
      display: flex;
      align-items: center;
      gap: 12px;
      background: #16182d;
      color: #f7f5f0;
      border-radius: 999px;
      padding: 10px 12px 10px 18px;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 13px;
      z-index: 2147483647;
    }
    .chip strong {
      font-family: Georgia, "Iowan Old Style", serif;
      font-weight: 400;
      font-size: 15px;
      letter-spacing: 0.01em;
    }
    .chip .dot {
      width: 6px;
      height: 6px;
      border-radius: 999px;
      background: #8fe3b0;
    }
    .chip .clock {
      font-variant-numeric: tabular-nums;
      letter-spacing: 0.04em;
      color: #c9cfef;
    }
    .chip button {
      appearance: none;
      cursor: pointer;
      background: rgba(247, 245, 240, 0.14);
      border: 0;
      border-radius: 999px;
      color: #f7f5f0;
      font-family: ui-sans-serif, system-ui, sans-serif;
      font-size: 12px;
      padding: 6px 14px;
    }
    .chip button:hover { background: rgba(247, 245, 240, 0.3); }
  `;

  const CREDIT = `
    <p class="credit">
      Developed by Isaura Santos
      <a href="https://www.linkedin.com/in/isaurasantos" target="_blank" rel="noopener noreferrer" aria-label="Isaura Santos on LinkedIn">
        <svg viewBox="0 0 24 24" width="10" height="10" aria-hidden="true">
          <path fill="currentColor" d="M6.5 8.8H3.6V20h2.9V8.8zM5 3.4C4 3.4 3.2 4.2 3.2 5.2S4 7 5 7s1.8-.8 1.8-1.8S6 3.4 5 3.4zM20.4 20h-2.9v-5.5c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9V20H10.7V8.8h2.8v1.5c.4-.7 1.4-1.8 2.9-1.8 3.1 0 3.7 2 3.7 4.7V20z"/>
        </svg>
      </a>
      <button type="button" class="settings-btn" data-action="settings" aria-label="Settings" title="Settings">
        <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
          <path fill="currentColor" d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.6-.22l-2.39.96a7.07 7.07 0 0 0-1.63-.94l-.36-2.54A.5.5 0 0 0 13.9 2h-3.8a.5.5 0 0 0-.49.42l-.36 2.54c-.59.24-1.13.55-1.63.94l-2.39-.96a.5.5 0 0 0-.6.22L2.71 8.48a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94L2.83 14.16a.5.5 0 0 0-.12.64l1.92 3.32c.14.24.43.34.68.22l2.39-.96c.5.39 1.04.7 1.63.94l.36 2.54c.05.24.25.42.49.42h3.8c.24 0 .44-.18.49-.42l.36-2.54c.59-.24 1.13-.55 1.63-.94l2.39.96c.25.12.54.02.68-.22l1.92-3.32a.5.5 0 0 0-.12-.64l-2.03-1.58zM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7z"/>
        </svg>
      </button>
    </p>
  `;

  const SESSION_CAPS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0];
  const BUDGETS = [30, 45, 60, 90];

  let state = sanityNormalize({});
  let shadow = null;
  let pickedIntent = null;
  let lastHref = location.href;
  let ticking = false;
  let watching = false;
  let ending = false;
  let showLogsPanel = false;
  let showQuoteScreen = false;
  let showSettingsPanel = false;
  let activeQuote = null;

  document.documentElement.setAttribute("data-sanity", "pending");
  patchHistory();
  boot();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    chrome.storage.local.get(null, (raw) => {
      state = sanityNormalize(raw);
      render();
    });
  });

  window.addEventListener("sanity:nav", () => {
    if (location.href === lastHref) return;
    lastHref = location.href;
    render();
  });

  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      render();
    }
  }, 400);

  async function boot() {
    state = sanityNormalize(await chrome.storage.local.get(null));
    const kind = sanityClassifyPath(location.pathname, location.search);
    pickedIntent = sanityGuessIntent(kind);
    await waitForBody();
    watchHost();
    render();
    startTick();
  }

  function startTick() {
    if (ticking) return;
    ticking = true;
    setInterval(() => {
      if (state.session && Date.now() >= state.session.endsAt && !ending) {
        ending = true;
        chrome.runtime.sendMessage({ type: "END_SESSION", reason: "timer" }, () => {
          ending = false;
        });
        return;
      }
      if (sanityIsSessionActive(state)) {
        chrome.runtime.sendMessage({ type: "TICK_BADGE" });
      }
    }, 1000);
  }

  function render() {
    const now = Date.now();
    let kind = sanityClassifyPath(location.pathname, location.search);

    if (kind === "auth" || hasGuestChrome() || sanityIsPaused(state, now)) {
      setMode("off");
      unmount();
      return;
    }

    if (kind === "home") {
      if (!hasAppChrome() && !sanityIsSessionActive(state, now)) {
        setMode("off");
        unmount();
        return;
      }
      kind = "feed";
    }

    // Active session: LinkedIn is normal. Timer lives on the Chrome badge / popup.
    if (sanityIsSessionActive(state, now)) {
      setMode("session");
      unmount();
      return;
    }

    ensureHost();
    setMode("gate");
    if (showSettingsPanel) {
      drawSettings();
      return;
    }
    if (!sanityCanStartSession(state)) {
      showQuoteScreen = false;
      drawBudget();
      return;
    }
    if (showQuoteScreen) {
      drawQuote();
      return;
    }
    if (state.justEnded) {
      drawEnded();
      return;
    }
    drawGate();
  }

  function setMode(mode) {
    document.documentElement.setAttribute("data-sanity", mode);
    document.documentElement.removeAttribute("data-sanity-intent");
  }

  function ensureHost() {
    const parent = document.body || document.documentElement;
    let host = document.getElementById(HOST_ID);
    if (!host) {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
      parent.appendChild(host);
      shadow = host.attachShadow({ mode: "open" });
      return;
    }
    shadow = host.shadowRoot;
    if (host.parentElement !== parent) {
      parent.appendChild(host);
    }
  }

  function unmount() {
    const host = document.getElementById(HOST_ID);
    if (host) host.remove();
    shadow = null;
  }

  function drawGate() {
    const remaining = sanityBudgetRemaining(state);
    const durations = durationOptions(remaining);
    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="layer">
        <div class="cover">
          <div class="aurora a1"></div>
          <div class="aurora a2"></div>
          <div class="aurora a3"></div>
          <div class="top">
            <span class="brand"><span class="mark">✻</span>sanity</span>
            <span class="meta">${state.usage.minutes} of ${state.settings.dailyBudgetMinutes} minutes today${
              sanityMaxSessions(state) > 0
                ? ` · ${state.usage.sessions}/${sanityMaxSessions(state)} sessions`
                : ""
            }</span>
          </div>
          <div class="sheet">
            <h1>What are you here to <span class="it">do?</span></h1>
            <p class="lede">
              <span class="line">You already know how this tab ends.</span>
              <span class="line">Name the job, set a clock, then get out.</span>
            </p>
            <div class="intents">
              ${SANITY_INTENTS.map((intent) => `
                <button class="intent ${intent.danger ? "is-danger" : ""} ${pickedIntent === intent.id ? "is-on" : ""}" data-intent="${intent.id}">
                  <span class="label">${intent.danger ? `<span class="warn" aria-hidden="true">⚠</span>` : ""}${intent.label}</span>
                  <span class="hint">${intent.hint}</span>
                </button>
              `).join("")}
            </div>
            <div class="when">How long</div>
            <div class="durations">
              ${durations.map((minutes) => `
                <button class="duration ${minutes === state.settings.defaultSessionMinutes ? "is-usual" : ""}" data-minutes="${minutes}" ${pickedIntent ? "" : "disabled"}>
                  ${minutes} min
                </button>
              `).join("")}
            </div>
            <button class="quiet" data-action="not-now">Not now</button>
          </div>
          ${CREDIT}
        </div>
      </div>
    `;
    shadow.querySelectorAll("[data-intent]").forEach((button) => {
      button.addEventListener("click", () => {
        const next = button.getAttribute("data-intent");
        const intent = sanityIntent(next);
        if (intent && intent.danger && pickedIntent !== next) {
          window.alert(intent.warning);
        }
        pickedIntent = next;
        drawGate();
      });
    });
    shadow.querySelectorAll("[data-minutes]").forEach((button) => {
      button.addEventListener("click", () => {
        if (!pickedIntent) return;
        const minutes = Number(button.getAttribute("data-minutes"));
        chrome.runtime.sendMessage(
          { type: "START_SESSION", intent: pickedIntent, minutes },
          () => enterLinkedIn()
        );
      });
    });
    shadow.querySelector("[data-action='not-now']").addEventListener("click", () => {
      showQuoteScreen = true;
      activeQuote = sanityRandomQuote();
      drawQuote();
    });
    bindCredit();
  }

  function bindCredit() {
    const settings = shadow.querySelector("[data-action='settings']");
    if (!settings) return;
    settings.addEventListener("click", () => {
      showSettingsPanel = true;
      showQuoteScreen = false;
      showLogsPanel = false;
      drawSettings();
    });
  }

  function sessionCapLabel(value) {
    return value === 0 ? "Unlimited" : String(value);
  }

  function drawSettings() {
    const maxSessions = sanityMaxSessions(state);
    const budgetOptions = BUDGETS.map(
      (minutes) =>
        `<option value="${minutes}" ${
          minutes === state.settings.dailyBudgetMinutes ? "selected" : ""
        }>${minutes} min</option>`
    ).join("");
    const durationOptionsHtml = SANITY_DURATIONS.map(
      (minutes) =>
        `<option value="${minutes}" ${
          minutes === state.settings.defaultSessionMinutes ? "selected" : ""
        }>${minutes} min</option>`
    ).join("");
    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="layer">
        <div class="cover">
          <div class="aurora a1"></div>
          <div class="aurora a2"></div>
          <div class="aurora a3"></div>
          <div class="top">
            <span class="brand"><span class="mark">✻</span>sanity</span>
            <span class="meta">settings</span>
          </div>
          <div class="sheet settings-sheet">
            <h1>Settings</h1>
            <p class="lede">
              <span class="line">Contain LinkedIn without quitting it.</span>
            </p>
            <label>
              <span>Daily budget</span>
              <select data-setting="budget">${budgetOptions}</select>
            </label>
            <label>
              <span>Default session</span>
              <select data-setting="default-session">${durationOptionsHtml}</select>
            </label>
            <div class="stepper-block">
              <div class="row" style="justify-content:space-between;width:100%">
                <p class="when" style="margin:0">Sessions / day</p>
                <p class="stepper-hint" style="margin:0">${sessionCapLabel(maxSessions)}</p>
              </div>
              <p class="stepper-hint">How many LinkedIn visits you allow yourself.</p>
              <div class="stepper" role="group" aria-label="Maximum sessions per day">
                <button type="button" class="stepper-btn" data-action="cap-down" aria-label="Fewer sessions">−</button>
                <p class="stepper-value" data-cap-display>${sessionCapLabel(maxSessions)}</p>
                <button type="button" class="stepper-btn" data-action="cap-up" aria-label="More sessions">+</button>
              </div>
            </div>
            <div class="actions" style="margin-top:28px">
              <button class="primary" data-action="back-settings">Done</button>
            </div>
          </div>
          ${CREDIT}
        </div>
      </div>
    `;
    shadow.querySelector("[data-setting='budget']").addEventListener("change", (event) => {
      chrome.runtime.sendMessage({
        type: "UPDATE_SETTINGS",
        settings: { dailyBudgetMinutes: Number(event.target.value) },
      });
    });
    shadow.querySelector("[data-setting='default-session']").addEventListener("change", (event) => {
      chrome.runtime.sendMessage({
        type: "UPDATE_SETTINGS",
        settings: { defaultSessionMinutes: Number(event.target.value) },
      });
    });
    const bumpCap = (delta) => {
      const current = sanityMaxSessions(state);
      const index = Math.max(0, SESSION_CAPS.indexOf(current));
      const next = SESSION_CAPS[Math.min(SESSION_CAPS.length - 1, Math.max(0, index + delta))];
      chrome.runtime.sendMessage({
        type: "UPDATE_SETTINGS",
        settings: { maxSessionsPerDay: next },
      });
    };
    shadow.querySelector("[data-action='cap-down']").addEventListener("click", () => bumpCap(-1));
    shadow.querySelector("[data-action='cap-up']").addEventListener("click", () => bumpCap(1));
    shadow.querySelector("[data-action='back-settings']").addEventListener("click", () => {
      showSettingsPanel = false;
      render();
    });
    bindCredit();
  }

  function drawQuote() {
    const quote = activeQuote || sanityRandomQuote();
    activeQuote = quote;
    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="layer">
        <div class="cover">
          <div class="aurora a1"></div>
          <div class="aurora a2"></div>
          <div class="aurora a3"></div>
          <div class="top">
            <span class="brand"><span class="mark">✻</span>sanity</span>
            <span class="meta">not now</span>
          </div>
          <div class="sheet is-quote">
            <div class="quote-block">
              <p class="quote-text">${quote.text}</p>
              <p class="quote-author">${quote.author}</p>
            </div>
            <div class="actions">
              <button class="primary" data-action="leave">Leave LinkedIn</button>
              <button class="quiet" data-action="back-gate">Back</button>
            </div>
          </div>
          ${CREDIT}
        </div>
      </div>
    `;
    shadow.querySelector("[data-action='leave']").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "LEAVE" });
    });
    shadow.querySelector("[data-action='back-gate']").addEventListener("click", () => {
      showQuoteScreen = false;
      activeQuote = null;
      if (state.justEnded) drawEnded();
      else drawGate();
    });
    bindCredit();
  }

  function drawEnded() {
    if (showLogsPanel) {
      drawLogs();
      return;
    }
    const remaining = sanityBudgetRemaining(state);
    const canExtend = !state.extended && remaining >= 1;
    const canAgain = remaining > 0 && sanitySessionsRemaining(state) > 0;
    const last = state.lastLog;
    const count = (state.log || []).length;
    const maxSessions = sanityMaxSessions(state);
    const sessionMeta =
      maxSessions > 0
        ? `${state.usage.sessions} of ${maxSessions} sessions · `
        : "";
    const logHtml = last
      ? `<p class="log-line">You came to <strong>${last.label.toLowerCase()}</strong>. Asked for ${last.requestedMinutes} min · stayed ${last.actualMinutes} min.</p>`
      : "";
    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="layer">
        <div class="cover">
          <div class="aurora a1"></div>
          <div class="aurora a2"></div>
          <div class="aurora a3"></div>
          <div class="top">
            <span class="brand"><span class="mark">✻</span>sanity</span>
            <span class="meta">${sessionMeta}${state.usage.minutes} of ${state.settings.dailyBudgetMinutes} minutes today</span>
          </div>
          <div class="sheet">
            <h1>That’s <span class="it">enough</span>.</h1>
            <p class="lede">
              <span class="line">LinkedIn still matters for the business.</span>
              <span class="line">So does leaving it. Close the tab and go build.</span>
            </p>
            ${logHtml}
            <div class="actions">
              <button class="primary" data-action="leave">Leave LinkedIn</button>
              <button class="secondary" data-action="quote">An inspiring quote before I go</button>
              <button class="secondary" data-action="logs">Check logs${count ? ` (${count})` : ""}</button>
              <div class="row">
                ${canExtend ? `<button class="quiet" data-action="extend">Five more minutes</button>` : ""}
                ${canAgain ? `<button class="quiet" data-action="again">Start another session</button>` : ""}
              </div>
            </div>
          </div>
          ${CREDIT}
        </div>
      </div>
    `;
    shadow.querySelector("[data-action='leave']").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "LEAVE" });
    });
    shadow.querySelector("[data-action='quote']").addEventListener("click", () => {
      showQuoteScreen = true;
      activeQuote = sanityRandomQuote();
      drawQuote();
    });
    shadow.querySelector("[data-action='logs']").addEventListener("click", () => {
      showLogsPanel = true;
      drawEnded();
    });
    const extend = shadow.querySelector("[data-action='extend']");
    if (extend) {
      extend.addEventListener("click", () => {
        showLogsPanel = false;
        chrome.runtime.sendMessage({ type: "EXTEND_SESSION" }, () => {
          enterLinkedIn();
        });
      });
    }
    const again = shadow.querySelector("[data-action='again']");
    if (again) {
      again.addEventListener("click", () => {
        showLogsPanel = false;
        chrome.runtime.sendMessage({ type: "CLEAR_ENDED" });
      });
    }
    bindCredit();
  }

  function drawLogs() {
    const entries = state.log || [];
    const items = entries.length
      ? entries
          .map((entry) => {
            const danger = Boolean(sanityIntent(entry.intent)?.danger);
            return `
              <div class="item ${danger ? "is-danger" : ""}">
                <div class="why">${danger ? "⚠ " : ""}${entry.label}</div>
                <div class="meta-line">${sanityFormatLogWhen(entry.startedAt)}</div>
                <div class="stats">Asked ${entry.requestedMinutes} min · stayed ${entry.actualMinutes} min</div>
              </div>
            `;
          })
          .join("")
      : `<p class="lede"><span class="line">No visits logged yet.</span></p>`;
    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="layer">
        <div class="cover">
          <div class="aurora a1"></div>
          <div class="aurora a2"></div>
          <div class="aurora a3"></div>
          <div class="top">
            <span class="brand"><span class="mark">✻</span>sanity</span>
            <span class="meta">${entries.length} visit${entries.length === 1 ? "" : "s"}</span>
          </div>
          <div class="sheet">
            <h1>Visit <span class="it">log</span></h1>
            <p class="lede">
              <span class="line">Why you came, how long you asked for, how long you stayed.</span>
            </p>
            <div class="log-panel">${items}</div>
            <div class="actions">
              <button class="primary" data-action="back">Back</button>
              ${entries.length ? `<button class="quiet" data-action="clear-logs">Clear all logs</button>` : ""}
            </div>
          </div>
          ${CREDIT}
        </div>
      </div>
    `;
    shadow.querySelector("[data-action='back']").addEventListener("click", () => {
      showLogsPanel = false;
      drawEnded();
    });
    const clear = shadow.querySelector("[data-action='clear-logs']");
    if (clear) {
      clear.addEventListener("click", () => {
        const ok = window.confirm(
          entries.length === 1
            ? "Clear this visit from the log?"
            : `Clear all ${entries.length} visits from the log?`
        );
        if (!ok) return;
        chrome.runtime.sendMessage({ type: "CLEAR_LOGS" }, () => {
          drawLogs();
        });
      });
    }
    bindCredit();
  }

  function drawBudget() {
    const budget = state.settings.dailyBudgetMinutes;
    const maxSessions = sanityMaxSessions(state);
    const sessionsDone = maxSessions > 0 && sanitySessionsRemaining(state) <= 0;
    const meta = sessionsDone
      ? `${state.usage.sessions} of ${maxSessions} sessions today`
      : `${budget} of ${budget} minutes today`;
    const title = sessionsDone
      ? `That’s <span class="it">your last</span> session.`
      : `You’re <span class="it">done</span> for today.`;
    const lede = sessionsDone
      ? `
              <span class="line">${maxSessions} session${maxSessions === 1 ? "" : "s"} is enough LinkedIn for one day.</span>
              <span class="line">Protect the rest of your attention. Close the tab and go build.</span>
            `
      : `
              <span class="line">${budget} minutes is a full GTM block.</span>
              <span class="line">Past that, LinkedIn stops being work and starts being a mood. Go ship.</span>
            `;
    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="layer">
        <div class="cover">
          <div class="aurora a1"></div>
          <div class="aurora a2"></div>
          <div class="aurora a3"></div>
          <div class="top">
            <span class="brand"><span class="mark">✻</span>sanity</span>
            <span class="meta">${meta}</span>
          </div>
          <div class="sheet">
            <h1>${title}</h1>
            <p class="lede">${lede}</p>
            <button class="primary" data-action="leave">Leave LinkedIn</button>
          </div>
          ${CREDIT}
        </div>
      </div>
    `;
    shadow.querySelector("[data-action='leave']").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "LEAVE" });
    });
    bindCredit();
  }

  function enterLinkedIn() {
    const feed = "https://www.linkedin.com/feed/";
    if (/^\/feed/i.test(location.pathname) || location.pathname === "/") {
      render();
      return;
    }
    location.assign(feed);
  }

  function durationOptions(remaining) {
    const options = SANITY_DURATIONS.filter((minutes) => minutes <= remaining);
    if (remaining > 0 && !options.includes(remaining)) options.push(remaining);
    return options;
  }

  function watchHost() {
    if (watching) return;
    watching = true;
    const observer = new MutationObserver(() => {
      if (document.documentElement.getAttribute("data-sanity") === "off") return;
      if (!document.getElementById(HOST_ID)) {
        shadow = null;
        render();
      }
    });
    observer.observe(document.documentElement, { childList: true });
    if (document.body) observer.observe(document.body, { childList: true });
  }

  function patchHistory() {
    const wrap = (method) =>
      function patched() {
        const result = method.apply(this, arguments);
        window.dispatchEvent(new Event("sanity:nav"));
        return result;
      };
    history.pushState = wrap(history.pushState);
    history.replaceState = wrap(history.replaceState);
    window.addEventListener("popstate", () => {
      window.dispatchEvent(new Event("sanity:nav"));
    });
  }

  function hasAppChrome() {
    return Boolean(
      document.getElementById("global-nav") ||
        document.querySelector(".global-nav") ||
        document.querySelector(".scaffold-layout")
    );
  }

  function hasGuestChrome() {
    return Boolean(
      document.querySelector('input[name="session_key"]') ||
        document.querySelector("input#username") ||
        document.querySelector(".join-form")
    );
  }

  function waitForBody() {
    if (document.body) return Promise.resolve();
    return new Promise((resolve) => {
      const observer = new MutationObserver(() => {
        if (document.body) {
          observer.disconnect();
          resolve();
        }
      });
      observer.observe(document.documentElement, { childList: true });
    });
  }
})();
