# sanity

LinkedIn is part of the job. The feed is not.

Sanity is a browser extension for founders, executives, and consultants who need LinkedIn for GTM and lose hours — then momentum — once the feed takes over.

It does not pretend you can quit LinkedIn. It makes you name the job, set a clock, and leave.

## What it does

- On LinkedIn only: asks what you are here to do, then opens normal LinkedIn
- Shows a live timer on the Chrome extension badge (and in the popup)
- Lets you use LinkedIn freely until the clock hits zero
- Stops the timer and logs your stay if you close the LinkedIn tab early
- Locks LinkedIn when time is up
- Rings a soft bell when the session timer ends
- Sessions / day wheel in the popup: 1–10 or unlimited
- Logs why you came, how long you asked for, and how long you stayed

When time is up, LinkedIn is covered by a lock screen. The toolbar badge shows `done`. You can leave, extend once by five minutes, or start another session if budget remains.

## Preview

A fake LinkedIn with the real gate, running locally:

```bash
python3 -m http.server 4173
```

Then open [http://127.0.0.1:4173/preview.html](http://127.0.0.1:4173/preview.html). Clocks run in seconds so you can see a session end.

## Install (Chrome, Arc, Brave, Edge)

1. Open `chrome://extensions` (or `arc://extensions`, `brave://extensions`, `edge://extensions`)
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Select this folder (`sanity`)
5. Open LinkedIn

You should see the sanity gate, not the feed.

## Use

Pick an intention, then a duration. That is the whole ritual.

- **Message someone** — messaging and profiles
- **Publish a post** — composer
- **Research a person** — search, profiles, companies
- **Inbox only** — messages
- **Check notifications** — the bell, then out
- **Scroll & comment** — feed unlocked, with a danger warning first

Most modes keep the feed behind the gate. Scroll unlocks it on purpose. When the clock hits zero, the session ends and LinkedIn is covered until you leave or start again. Pause for an hour from the toolbar popup only if you truly have live work that cannot fit a session.

## Why this shape

Hiding the feed is not enough. You will still open the tab to “check one thing” and come out thirty minutes later lower than when you went in. Sanity puts friction in front of the tab, a job on the other side of it, and a clock on the wall.
