const statusLine = document.getElementById("status-line");
const sessionCard = document.getElementById("session-card");
const sessionIntent = document.getElementById("session-intent");
const sessionClock = document.getElementById("session-clock");
const endSession = document.getElementById("end-session");
const startCard = document.getElementById("start-card");
const intentList = document.getElementById("intent-list");
const durationList = document.getElementById("duration-list");
const startSessionBtn = document.getElementById("start-session");
const startHint = document.getElementById("start-hint");
const usageLine = document.getElementById("usage-line");
const usageFill = document.getElementById("usage-fill");
const budget = document.getElementById("budget");
const defaultSession = document.getElementById("default-session");
const pause = document.getElementById("pause");
const unpause = document.getElementById("unpause");
const logSection = document.getElementById("log-section");
const logList = document.getElementById("log-list");
const logEmpty = document.getElementById("log-empty");
const checkLogs = document.getElementById("check-logs");
const hideLogs = document.getElementById("hide-logs");
const clearLogs = document.getElementById("clear-logs");
const sessionCapValue = document.getElementById("session-cap-value");
const sessionCapDisplay = document.getElementById("session-cap-display");
const sessionCapDown = document.getElementById("session-cap-down");
const sessionCapUp = document.getElementById("session-cap-up");
const mainView = document.getElementById("main-view");
const settingsView = document.getElementById("settings-view");
const openSettings = document.getElementById("open-settings");
const closeSettings = document.getElementById("close-settings");

const BUDGETS = [30, 45, 60, 90];
const SESSION_CAPS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0];
let pauseArmed = false;
let state = sanityNormalize({});
let onLinkedIn = false;
let logsOpen = false;
let settingsOpen = false;
let pickedIntent = null;
let pickedMinutes = null;

BUDGETS.forEach((minutes) => {
  const option = document.createElement("option");
  option.value = String(minutes);
  option.textContent = `${minutes} min`;
  budget.appendChild(option);
});

SANITY_DURATIONS.forEach((minutes) => {
  const option = document.createElement("option");
  option.value = String(minutes);
  option.textContent = `${minutes} min`;
  defaultSession.appendChild(option);
});

buildStartControls();

chrome.storage.local.get(null, (raw) => {
  state = sanityNormalize(raw);
  pickedMinutes = state.settings.defaultSessionMinutes;
  detectTab().then(draw);
});

chrome.storage.onChanged.addListener(() => {
  chrome.storage.local.get(null, (raw) => {
    state = sanityNormalize(raw);
    draw();
  });
});

async function detectTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    onLinkedIn = Boolean(tab && tab.url && sanityIsLinkedInUrl(tab.url));
  } catch (_error) {
    onLinkedIn = false;
  }
}

setInterval(() => {
  if (!sanityIsSessionActive(state)) return;
  sessionClock.textContent = sanityFormatClock(sanityRemainingMs(state));
  chrome.runtime.sendMessage({ type: "TICK_BADGE" });
}, 1000);

openSettings.addEventListener("click", () => {
  settingsOpen = true;
  draw();
});

closeSettings.addEventListener("click", () => {
  settingsOpen = false;
  draw();
});

endSession.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "END_SESSION" });
});

checkLogs.addEventListener("click", () => {
  logsOpen = true;
  draw();
  logSection.scrollIntoView({ behavior: "smooth", block: "nearest" });
});

hideLogs.addEventListener("click", () => {
  logsOpen = false;
  draw();
});

clearLogs.addEventListener("click", () => {
  const entries = state.log || [];
  if (!entries.length) return;
  const ok = window.confirm(
    entries.length === 1
      ? "Clear this visit from the log?"
      : `Clear all ${entries.length} visits from the log?`
  );
  if (!ok) return;
  chrome.runtime.sendMessage({ type: "CLEAR_LOGS" });
});

startSessionBtn.addEventListener("click", async () => {
  if (!pickedIntent || !pickedMinutes) return;
  const intent = sanityIntent(pickedIntent);
  if (intent && intent.danger) {
    const ok = window.confirm(intent.warning + "\n\nContinue anyway?");
    if (!ok) return;
  }
  if (state.justEnded) {
    await chrome.runtime.sendMessage({ type: "CLEAR_ENDED" });
  }
  await chrome.runtime.sendMessage({
    type: "START_SESSION",
    intent: pickedIntent,
    minutes: pickedMinutes,
  });
  await chrome.runtime.sendMessage({ type: "OPEN_LINKEDIN" });
  window.close();
});

budget.addEventListener("change", () => {
  chrome.runtime.sendMessage({
    type: "UPDATE_SETTINGS",
    settings: { dailyBudgetMinutes: Number(budget.value) },
  });
});

defaultSession.addEventListener("change", () => {
  const minutes = Number(defaultSession.value);
  chrome.runtime.sendMessage({
    type: "UPDATE_SETTINGS",
    settings: { defaultSessionMinutes: minutes },
  });
  pickedMinutes = minutes;
  drawStartControls();
});

sessionCapDown.addEventListener("click", () => stepSessionCap(-1));
sessionCapUp.addEventListener("click", () => stepSessionCap(1));

pause.addEventListener("click", () => {
  if (!pauseArmed) {
    pauseArmed = true;
    pause.textContent = "Click again to confirm";
    return;
  }
  pauseArmed = false;
  pause.textContent = "Pause 1 hour";
  chrome.runtime.sendMessage({ type: "PAUSE", ms: 60 * 60 * 1000 });
});

unpause.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "UNPAUSE" });
});

function buildStartControls() {
  intentList.innerHTML = SANITY_INTENTS.map(
    (intent) => `
    <button type="button" data-intent="${intent.id}" title="${intent.hint}" class="${intent.danger ? "is-danger" : ""}">
      <span class="label">${intent.danger ? "⚠ " : ""}${intent.label}</span>
      ${intent.danger ? `<span class="hint">${intent.hint}</span>` : ""}
    </button>
  `
  ).join("");

  intentList.querySelectorAll("[data-intent]").forEach((button) => {
    button.addEventListener("click", () => {
      pickedIntent = button.getAttribute("data-intent");
      drawStartControls();
    });
  });

  drawStartControls();
}

function drawStartControls() {
  const remaining = sanityBudgetRemaining(state);
  intentList.querySelectorAll("[data-intent]").forEach((button) => {
    button.classList.toggle("is-on", button.getAttribute("data-intent") === pickedIntent);
  });

  const options = SANITY_DURATIONS.filter((minutes) => minutes <= remaining);
  if (remaining > 0 && remaining < 10 && !options.includes(remaining)) options.push(remaining);
  if (!options.includes(pickedMinutes) && options.length) {
    pickedMinutes = options.includes(state.settings.defaultSessionMinutes)
      ? state.settings.defaultSessionMinutes
      : options[0];
  }

  durationList.innerHTML = options
    .map(
      (minutes) => `
    <button type="button" data-minutes="${minutes}" class="${minutes === pickedMinutes ? "is-on" : ""}">
      ${minutes} min
    </button>
  `
    )
    .join("");

  durationList.querySelectorAll("[data-minutes]").forEach((button) => {
    button.addEventListener("click", () => {
      pickedMinutes = Number(button.getAttribute("data-minutes"));
      drawStartControls();
    });
  });

  const canStart = Boolean(
    pickedIntent && pickedMinutes && sanityCanStartSession(state) && !sanityIsPaused(state)
  );
  startSessionBtn.disabled = !canStart;
  startSessionBtn.textContent = onLinkedIn ? "Start session" : "Start on LinkedIn";
  if (!sanityCanStartSession(state)) {
    if (sanitySessionsRemaining(state) <= 0) {
      startHint.textContent = "Session limit reached for today.";
    } else {
      startHint.textContent = "Daily budget used. Come back tomorrow.";
    }
  } else if (!pickedIntent) {
    startHint.textContent = "Pick a reason and a time, then start.";
  } else {
    startHint.textContent = onLinkedIn
      ? "Starts the timer and unlocks LinkedIn."
      : "Opens LinkedIn and starts the timer.";
  }
}

function sessionCapLabel(value) {
  return value === 0 ? "Unlimited" : String(value);
}

function sessionCapIndex(value) {
  const idx = SESSION_CAPS.indexOf(value);
  return idx >= 0 ? idx : SESSION_CAPS.length - 1;
}

function syncSessionCap() {
  const current = sanityMaxSessions(state);
  const label = sessionCapLabel(current);
  sessionCapValue.textContent = label;
  sessionCapDisplay.textContent = label;
  const idx = sessionCapIndex(current);
  sessionCapDown.disabled = idx <= 0;
  sessionCapUp.disabled = idx >= SESSION_CAPS.length - 1;
}

function stepSessionCap(delta) {
  const idx = sessionCapIndex(sanityMaxSessions(state));
  const nextIdx = Math.max(0, Math.min(SESSION_CAPS.length - 1, idx + delta));
  const next = SESSION_CAPS[nextIdx];
  if (next === sanityMaxSessions(state)) return;
  chrome.runtime.sendMessage({
    type: "UPDATE_SETTINGS",
    settings: { maxSessionsPerDay: next },
  });
}

function setStatus(label, stateName) {
  statusLine.textContent = label;
  document.body.dataset.state = stateName;
}

function draw() {
  const now = Date.now();
  document.body.dataset.view = settingsOpen ? "settings" : "main";
  mainView.hidden = settingsOpen;
  settingsView.hidden = !settingsOpen;
  openSettings.hidden = settingsOpen;

  budget.value = String(state.settings.dailyBudgetMinutes);
  defaultSession.value = String(state.settings.defaultSessionMinutes);
  syncSessionCap();

  const maxSessions = sanityMaxSessions(state);
  const sessionsText =
    maxSessions > 0
      ? `${state.usage.sessions} / ${maxSessions} sessions · `
      : `${state.usage.sessions} session${state.usage.sessions === 1 ? "" : "s"} · `;
  usageLine.textContent = `${sessionsText}${state.usage.minutes} / ${state.settings.dailyBudgetMinutes} min`;
  const ratio = Math.min(1, state.usage.minutes / Math.max(1, state.settings.dailyBudgetMinutes));
  usageFill.style.width = `${ratio * 100}%`;
  drawLog();
  drawStartControls();

  const paused = sanityIsPaused(state, now);
  pause.hidden = paused;
  unpause.hidden = !paused;

  if (settingsOpen) {
    setStatus("settings", "ready");
    return;
  }

  if (paused) {
    const minutes = Math.max(1, Math.ceil((state.settings.pausedUntil - now) / 60000));
    setStatus(`paused · ${minutes}m`, "paused");
    sessionCard.hidden = true;
    startCard.hidden = true;
    return;
  }

  if (sanityIsSessionActive(state, now)) {
    const intent = sanityIntent(state.session.intent);
    setStatus("running", "running");
    sessionCard.hidden = false;
    startCard.hidden = true;
    sessionIntent.textContent = intent ? intent.label : "Session";
    sessionClock.textContent = sanityFormatClock(sanityRemainingMs(state));
    return;
  }

  sessionCard.hidden = true;
  const canStart = sanityCanStartSession(state);
  startCard.hidden = !canStart;

  if (!canStart) {
    setStatus("done today", "done");
    return;
  }
  if (state.justEnded) {
    setStatus("locked", "locked");
    return;
  }
  setStatus(onLinkedIn ? "armed" : "ready", onLinkedIn ? "armed" : "ready");
}

function drawLog() {
  const entries = state.log || [];
  checkLogs.textContent = entries.length ? `Check logs (${entries.length})` : "Check logs";
  checkLogs.hidden = logsOpen;
  logSection.hidden = !logsOpen;
  clearLogs.hidden = !entries.length;

  if (!entries.length) {
    logList.innerHTML = "";
    logEmpty.hidden = false;
    return;
  }
  logEmpty.hidden = true;
  logList.innerHTML = entries
    .map((entry) => {
      const danger = Boolean(sanityIntent(entry.intent)?.danger);
      return `
        <li class="${danger ? "is-danger" : ""}">
          <span class="why">${danger ? `<span class="warn-mark">⚠</span> ` : ""}${entry.label}</span>
          <span class="when">${sanityFormatLogWhen(entry.startedAt)}</span>
          <span class="times">Asked ${entry.requestedMinutes} min · stayed ${entry.actualMinutes} min</span>
        </li>
      `;
    })
    .join("");
}
