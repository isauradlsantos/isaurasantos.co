importScripts("shared.js");

const ALARM_END = "sanity-session-end";
const ALARM_BADGE = "sanity-badge";
const FEED_RULESET = "linkedin_feed";
const LINKEDIN_TAB_URLS = ["*://linkedin.com/*", "*://*.linkedin.com/*"];
const linkedInTabIds = new Set();

chrome.runtime.onInstalled.addListener(async () => {
  const state = sanityNormalize(await chrome.storage.local.get(null));
  await chrome.storage.local.set(state);
  await syncAlarm(state);
  await syncFeedRules(state);
  await updateBadge();
  await refreshLinkedInTabs();
});

chrome.runtime.onStartup.addListener(async () => {
  const state = sanityNormalize(await chrome.storage.local.get(null));
  if (state.session && Date.now() >= state.session.endsAt) {
    await endSession("timer");
  } else {
    await chrome.storage.local.set(state);
    await syncAlarm(state);
    await syncFeedRules(state);
    await updateBadge();
  }
  await refreshLinkedInTabs();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(() => sendResponse({ ok: true }))
    .catch((error) => sendResponse({ ok: false, error: String(error) }));
  return true;
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_END) {
    await endSession("timer");
  }
  if (alarm.name === ALARM_BADGE) {
    await updateBadge();
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "end-session") {
    await endSession("manual");
  }
});

chrome.storage.onChanged.addListener(() => {
  updateBadge();
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab.url || "";
  if (url && sanityIsLinkedInUrl(url)) {
    linkedInTabIds.add(tabId);
    return;
  }
  if (changeInfo.url && linkedInTabIds.has(tabId)) {
    linkedInTabIds.delete(tabId);
    await maybeEndSessionIfLeftLinkedIn("closed");
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  if (tab.id != null && tab.url && sanityIsLinkedInUrl(tab.url)) {
    linkedInTabIds.add(tab.id);
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (!linkedInTabIds.has(tabId)) return;
  linkedInTabIds.delete(tabId);
  await maybeEndSessionIfLeftLinkedIn("closed");
});

refreshLinkedInTabs();

async function refreshLinkedInTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: LINKEDIN_TAB_URLS });
    linkedInTabIds.clear();
    tabs.forEach((tab) => {
      if (typeof tab.id === "number") linkedInTabIds.add(tab.id);
    });
  } catch (_error) {
    /* tabs may be unavailable during early startup */
  }
}

async function maybeEndSessionIfLeftLinkedIn(reason) {
  const state = sanityNormalize(await chrome.storage.local.get(null));
  if (!sanityIsSessionActive(state)) return;

  let remaining = [];
  try {
    remaining = await chrome.tabs.query({ url: LINKEDIN_TAB_URLS });
  } catch (_error) {
    return;
  }
  if (remaining.length > 0) {
    remaining.forEach((tab) => {
      if (typeof tab.id === "number") linkedInTabIds.add(tab.id);
    });
    return;
  }

  // Left LinkedIn early — stop the clock and write the stay to the log.
  // Do not show the lock screen; they chose to leave.
  await endSession(reason, { lock: false });
}

async function handleMessage(message, sender) {
  switch (message.type) {
    case "START_SESSION":
      await startSession(message.intent, message.minutes);
      return;
    case "END_SESSION":
      await endSession(message.reason || "manual");
      return;
    case "EXTEND_SESSION":
      await extendSession();
      return;
    case "CLEAR_ENDED":
      await patchState((state) => {
        state.justEnded = false;
        state.lastLog = null;
      });
      return;
    case "CLEAR_LOGS":
      await patchState((state) => {
        state.log = [];
        state.lastLog = null;
      });
      return;
    case "PAUSE":
      await pauseFor(message.ms || 60 * 60 * 1000);
      return;
    case "UNPAUSE":
      await patchState((state) => {
        state.settings.pausedUntil = 0;
      });
      return;
    case "UPDATE_SETTINGS":
      await patchState((state) => {
        Object.assign(state.settings, message.settings || {});
      });
      return;
    case "TICK_BADGE":
      await updateBadge();
      return;
    case "OPEN_LINKEDIN":
      await openLinkedIn();
      return;
    case "LEAVE":
      await leaveLinkedIn(sender);
      return;
    default:
      return;
  }
}

async function leaveLinkedIn(sender) {
  // Only the top frame of the tab that asked may close that tab, and nothing else.
  if (!sender || !sender.tab || typeof sender.tab.id !== "number") return;
  if (sender.frameId !== 0) return;

  let tab;
  try {
    tab = await chrome.tabs.get(sender.tab.id);
  } catch (_error) {
    return;
  }
  if (!tab.url || !sanityIsLinkedInUrl(tab.url)) return;

  const openTabs = await chrome.tabs.query({ windowType: "normal" });
  const lastOne = openTabs.every((other) => other.id === tab.id);

  try {
    await chrome.tabs.remove(tab.id);
  } catch (_error) {
    return;
  }

  // Closing LinkedIn mid-session stops the timer via tabs.onRemoved.
  // If this was the last normal tab, shut the browser windows down.
  if (!lastOne) return;

  // Nothing else was open, so shut the browser down instead of leaving an empty shell.
  try {
    const windows = await chrome.windows.getAll();
    await Promise.all(
      windows.map((window) => chrome.windows.remove(window.id).catch(() => {}))
    );
  } catch (_error) {
    /* already gone */
  }
}

async function openLinkedIn() {
  const feed = "https://www.linkedin.com/feed/";
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const existing = tabs.find((tab) => tab.url && sanityIsLinkedInUrl(tab.url));
  if (existing && existing.id) {
    await chrome.tabs.update(existing.id, { active: true, url: feed });
    return;
  }
  await chrome.tabs.create({ url: feed });
}

async function startSession(intentId, minutes) {
  const intent = sanityIntent(intentId);
  if (!intent) return;
  await patchState(async (state) => {
    if (sanityIsPaused(state) || sanityIsSessionActive(state)) return;
    if (!sanityCanStartSession(state)) return;
    const remaining = sanityBudgetRemaining(state);
    const duration = Math.max(1, Math.min(Number(minutes) || 15, remaining));
    const now = Date.now();
    state.session = {
      intent: intent.id,
      startedAt: now,
      requestedMinutes: duration,
      durationMs: duration * 60 * 1000,
      endsAt: now + duration * 60 * 1000,
    };
    state.usage.sessions = (Number(state.usage.sessions) || 0) + 1;
    state.justEnded = false;
    state.extended = false;
    state.lastLog = null;
    state.lastIntent = intent.id;
  });
}

async function endSession(reason = "manual", { lock = true } = {}) {
  let closed = false;
  let shouldChime = false;
  await patchState((state) => {
    if (!state.session) return;
    const timedOut = Date.now() >= state.session.endsAt - 750;
    shouldChime = reason === "timer" || timedOut;
    sanityCloseSession(state, shouldChime ? "timer" : reason);
    state.justEnded = lock;
    closed = true;
  });
  if (closed && shouldChime) {
    await playEndBell();
  }
}

async function ensureOffscreen() {
  try {
    if (chrome.offscreen.hasDocument && (await chrome.offscreen.hasDocument())) {
      return;
    }
  } catch (_error) {
    /* older Chromium */
  }
  try {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Play a soft bell when a sanity session timer ends",
    });
  } catch (_error) {
    /* already exists or unavailable */
  }
}

async function playEndBell() {
  try {
    await ensureOffscreen();
    await chrome.runtime.sendMessage({ type: "PLAY_BELL" });
  } catch (_error) {
    /* audio path unavailable */
  }
}

async function extendSession() {
  await patchState((state) => {
    if (state.extended) return;
    const remainingBefore = sanityBudgetRemaining(state);
    if (state.session) {
      sanityCloseSession(state, "extend");
    }
    const remaining = Math.min(remainingBefore, sanityBudgetRemaining(state));
    if (remaining <= 0) {
      state.justEnded = true;
      return;
    }
    const intentId = state.lastIntent;
    if (!sanityIntent(intentId)) {
      state.justEnded = true;
      return;
    }
    const duration = Math.min(5, remaining);
    const now = Date.now();
    state.session = {
      intent: intentId,
      startedAt: now,
      requestedMinutes: duration,
      durationMs: duration * 60 * 1000,
      endsAt: now + duration * 60 * 1000,
    };
    state.extended = true;
    state.justEnded = false;
    state.lastLog = null;
  });
}

async function pauseFor(ms) {
  await patchState((state) => {
    if (state.session) {
      sanityCloseSession(state, "pause");
    }
    state.justEnded = false;
    state.lastLog = null;
    state.settings.pausedUntil = Date.now() + ms;
  });
}

async function patchState(mutator) {
  const state = sanityNormalize(await chrome.storage.local.get(null));
  await mutator(state);
  await chrome.storage.local.set(state);
  await syncAlarm(state);
  await syncFeedRules(state);
  await updateBadge();
}

async function syncAlarm(state) {
  await chrome.alarms.clear(ALARM_END);
  await chrome.alarms.clear(ALARM_BADGE);
  if (sanityIsSessionActive(state)) {
    await chrome.alarms.create(ALARM_END, { when: state.session.endsAt });
    await chrome.alarms.create(ALARM_BADGE, { periodInMinutes: 1 });
  }
}

async function syncFeedRules(state) {
  // Only block feed pagination when LinkedIn is locked (no active session).
  const unlocked = sanityIsSessionActive(state);
  try {
    if (unlocked) {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        disableRulesetIds: [FEED_RULESET],
      });
    } else {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: [FEED_RULESET],
      });
    }
  } catch (_error) {
    /* ruleset may already be in the desired state */
  }
}

async function updateBadge() {
  const state = sanityNormalize(await chrome.storage.local.get(null));
  if (sanityIsSessionActive(state)) {
    const ms = sanityRemainingMs(state);
    const total = Math.max(0, Math.ceil(ms / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = total % 60;
    const text =
      minutes >= 10 ? `${minutes}m` : `${minutes}:${String(seconds).padStart(2, "0")}`;
    await chrome.action.setBadgeText({ text });
    await chrome.action.setBadgeBackgroundColor({ color: "#16182D" });
    try {
      await chrome.action.setBadgeTextColor({ color: "#F7F5F0" });
    } catch (_error) {
      /* older Chromium */
    }
  } else if (state.justEnded) {
    await chrome.action.setBadgeText({ text: "done" });
    await chrome.action.setBadgeBackgroundColor({ color: "#8B2E1A" });
    try {
      await chrome.action.setBadgeTextColor({ color: "#FFF6F0" });
    } catch (_error) {
      /* older Chromium */
    }
  } else {
    await chrome.action.setBadgeText({ text: "" });
  }
}
