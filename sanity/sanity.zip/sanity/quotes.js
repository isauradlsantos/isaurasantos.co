const SANITY_QUOTES = [
  {
    text: "Nature does not hurry, yet everything is accomplished.",
    author: "Lao Tzu",
  },
  {
    text: "Adopt the pace of nature: her secret is patience.",
    author: "Ralph Waldo Emerson",
  },
  {
    text: "There is more to life than increasing its speed.",
    author: "Mahatma Gandhi",
  },
  {
    text: "How we spend our days is, of course, how we spend our lives.",
    author: "Annie Dillard",
  },
  {
    text: "It is not enough to be busy. The question is: what are we busy about?",
    author: "Henry David Thoreau",
  },
  {
    text: "Muddy water is best cleared by leaving it alone.",
    author: "Alan Watts",
  },
  {
    text: "Wherever you are, be all there.",
    author: "Jim Elliot",
  },
  {
    text: "Almost everything will work again if you unplug it for a few minutes, including you.",
    author: "Anne Lamott",
  },
  {
    text: "Rest is not idleness.",
    author: "John Lubbock",
  },
  {
    text: "The quieter you become, the more you can hear.",
    author: "Ram Dass",
  },
  {
    text: "Look deep into nature, and then you will understand everything better.",
    author: "Albert Einstein",
  },
  {
    text: "The present moment is filled with joy and happiness. If you are attentive, you will see it.",
    author: "Thich Nhat Hanh",
  },
  {
    text: "You are the sky. Everything else — it’s just the weather.",
    author: "Pema Chödrön",
  },
  {
    text: "Nothing can bring you peace but yourself.",
    author: "Ralph Waldo Emerson",
  },
  {
    text: "An early-morning walk is a blessing for the whole day.",
    author: "Henry David Thoreau",
  },
  {
    text: "I took a walk in the woods and came out taller than the trees.",
    author: "Henry David Thoreau",
  },
  {
    text: "To pay attention, this is our endless and proper work.",
    author: "Mary Oliver",
  },
  {
    text: "Instructions for living a life: Pay attention. Be astonished. Tell about it.",
    author: "Mary Oliver",
  },
  {
    text: "Rivers know this: there is no hurry. We shall get there some day.",
    author: "A. A. Milne",
  },
  {
    text: "All truly great thoughts are conceived while walking.",
    author: "Friedrich Nietzsche",
  },
  {
    text: "Within you there is a stillness and a sanctuary to which you can retreat at any time.",
    author: "Hermann Hesse",
  },
  {
    text: "Be patient toward all that is unsolved in your heart.",
    author: "Rainer Maria Rilke",
  },
  {
    text: "Let everything happen to you: beauty and terror. Just keep going. No feeling is final.",
    author: "Rainer Maria Rilke",
  },
  {
    text: "The privilege of a lifetime is being who you are.",
    author: "Joseph Campbell",
  },
  {
    text: "Believe you can and you’re halfway there.",
    author: "Theodore Roosevelt",
  },
  {
    text: "Calm mind brings inner strength and self-confidence.",
    author: "Dalai Lama",
  },
  {
    text: "The little things? The little moments? They aren’t little.",
    author: "Jon Kabat-Zinn",
  },
  {
    text: "No valid plans for the future can be made by those who have no capacity for living now.",
    author: "Alan Watts",
  },
  {
    text: "Be still. Stillness reveals the secrets of eternity.",
    author: "Lao Tzu",
  },
  {
    text: "He who can no longer pause to wonder and stand rapt in awe is as good as dead.",
    author: "Albert Einstein",
  },
  {
    text: "Nature always wears the colors of the spirit.",
    author: "Ralph Waldo Emerson",
  },
  {
    text: "In the midst of movement and chaos, keep stillness inside of you.",
    author: "Deepak Chopra",
  },
  {
    text: "Slow down and enjoy life. It’s not only the scenery you miss by going too fast — you also miss the sense of where you are going and why.",
    author: "Eddie Cantor",
  },
  {
    text: "The best time to plant a tree was twenty years ago. The second best time is now.",
    author: "Chinese proverb",
  },
  {
    text: "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.",
    author: "Buddha",
  },
  {
    text: "Your mind will answer most questions if you learn to relax and wait for the answer.",
    author: "William S. Burroughs",
  },
  {
    text: "Solitude is independence.",
    author: "Hermann Hesse",
  },
  {
    text: "Beware the barrenness of a busy life.",
    author: "Socrates",
  },
  {
    text: "The time you enjoy wasting is not wasted time.",
    author: "Marthe Troly-Curtin",
  },
  {
    text: "What you get by achieving your goals is not as important as what you become by achieving your goals.",
    author: "Zig Ziglar",
  },
  {
    text: "Keep your face always toward the sunshine — and shadows will fall behind you.",
    author: "Walt Whitman",
  },
  {
    text: "The only way to make sense out of change is to plunge into it, move with it, and join the dance.",
    author: "Alan Watts",
  },
  {
    text: "You cannot swim for new horizons until you have courage to lose sight of the shore.",
    author: "William Faulkner",
  },
  {
    text: "Real generosity toward the future lies in giving all to the present.",
    author: "Albert Camus",
  },
  {
    text: "We must be willing to let go of the life we planned so as to have the life that is waiting for us.",
    author: "Joseph Campbell",
  },
  {
    text: "Silence is a source of great strength.",
    author: "Lao Tzu",
  },
  {
    text: "The goal isn’t to get somewhere faster. The goal is to be here more fully.",
    author: "Thich Nhat Hanh",
  },
  {
    text: "Go confidently in the direction of your dreams. Live the life you have imagined.",
    author: "Henry David Thoreau",
  },
  {
    text: "In every walk with nature one receives far more than he seeks.",
    author: "John Muir",
  },
  {
    text: "You have been assigned this mountain to show others it can be moved.",
    author: "Mel Robbins",
  },
];

function sanityRandomQuote() {
  const list = SANITY_QUOTES;
  if (!list || !list.length) {
    return { text: "Close the tab and go build.", author: "sanity" };
  }
  return list[Math.floor(Math.random() * list.length)];
}
