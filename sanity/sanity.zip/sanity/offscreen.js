chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === "PLAY_BELL") {
    sanityPlayBell();
  }
});
