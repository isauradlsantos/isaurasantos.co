const SANITY_DEFAULTS = {
  dailyBudgetMinutes: 45,
  defaultSessionMinutes: 15,
  maxSessionsPerDay: 0,
  pausedUntil: 0,
};

const SANITY_INTENTS = [
  {
    id: "message",
    label: "Message someone",
    hint: "A real person. A real note.",
    home: "https://www.linkedin.com/feed/",
    allow: ["messaging", "profile", "feed", "search", "notifications", "network", "compose", "company", "sales", "jobs", "other", "home"],
  },
  {
    id: "publish",
    label: "Publish a post",
    hint: "Write one thing. Then stop.",
    home: "https://www.linkedin.com/feed/",
    allow: ["messaging", "profile", "feed", "search", "notifications", "network", "compose", "company", "sales", "jobs", "other", "home"],
  },
  {
    id: "research",
    label: "Research a person",
    hint: "Find who you need. Then leave.",
    home: "https://www.linkedin.com/feed/",
    allow: ["messaging", "profile", "feed", "search", "notifications", "network", "compose", "company", "sales", "jobs", "other", "home"],
  },
  {
    id: "inbox",
    label: "Inbox only",
    hint: "Open messages. Reply. Leave.",
    home: "https://www.linkedin.com/messaging/",
    allow: ["messaging", "profile", "feed", "search", "notifications", "network", "compose", "company", "sales", "jobs", "other", "home"],
  },
  {
    id: "notifications",
    label: "Check notifications",
    hint: "Scan the bell. Then leave.",
    home: "https://www.linkedin.com/notifications/",
    allow: ["messaging", "profile", "feed", "search", "notifications", "network", "compose", "company", "sales", "jobs", "other", "home"],
  },
  {
    id: "scroll",
    label: "Scroll & comment",
    hint: "The slippery one. Proceed carefully.",
    home: "https://www.linkedin.com/feed/",
    allow: ["messaging", "profile", "feed", "search", "notifications", "network", "compose", "company", "sales", "jobs", "other", "home"],
    danger: true,
    warning:
      "This is the mode that eats the afternoon.\n\n" +
      "Scrolling and commenting feel like work. They usually aren’t.\n\n" +
      "Set a short clock. Do the one useful thing. Get out before the comparison starts.",
  },
];

const SANITY_DURATIONS = [5, 10, 15, 25];
const SANITY_LOG_LIMIT = 100;

function sanityTodayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function sanityNormalize(raw = {}) {
  const settings = { ...SANITY_DEFAULTS, ...(raw.settings || {}) };
  settings.maxSessionsPerDay = Math.max(0, Number(settings.maxSessionsPerDay) || 0);
  const usage = raw.usage || { date: sanityTodayKey(), minutes: 0, sessions: 0 };
  if (usage.date !== sanityTodayKey()) {
    usage.date = sanityTodayKey();
    usage.minutes = 0;
    usage.sessions = 0;
  }
  usage.minutes = Number(usage.minutes) || 0;
  usage.sessions = Number(usage.sessions) || 0;
  const log = Array.isArray(raw.log) ? raw.log.slice(0, SANITY_LOG_LIMIT) : [];
  return {
    settings,
    usage,
    session: raw.session || null,
    justEnded: Boolean(raw.justEnded),
    extended: Boolean(raw.extended),
    lastIntent: raw.lastIntent || null,
    lastLog: raw.lastLog || null,
    log,
  };
}

function sanityIsPaused(state, now = Date.now()) {
  return Number(state.settings.pausedUntil || 0) > now;
}

function sanityIsSessionActive(state, now = Date.now()) {
  const session = state.session;
  return Boolean(session && session.endsAt > now);
}

function sanityBudgetRemaining(state) {
  return Math.max(0, state.settings.dailyBudgetMinutes - state.usage.minutes);
}

function sanityMaxSessions(state) {
  return Math.max(0, Number(state.settings.maxSessionsPerDay) || 0);
}

function sanitySessionsRemaining(state) {
  const max = sanityMaxSessions(state);
  if (max <= 0) return Infinity;
  return Math.max(0, max - (Number(state.usage.sessions) || 0));
}

function sanityCanStartSession(state) {
  return sanityBudgetRemaining(state) > 0 && sanitySessionsRemaining(state) > 0;
}

function sanityIntent(id) {
  return SANITY_INTENTS.find((item) => item.id === id) || null;
}

function sanityClassifyPath(pathname, search = "") {
  const path = pathname || "/";
  const query = search || "";
  if (/\/(login|uas|checkpoint|signup|authwall|legal|help)/i.test(path)) return "auth";
  if (/^\/messaging/i.test(path)) return "messaging";
  if (/^\/notifications/i.test(path)) return "notifications";
  if (/^\/search/i.test(path)) return "search";
  if (/^\/in\//i.test(path)) return "profile";
  if (/^\/company\//i.test(path)) return "company";
  if (/^\/sales/i.test(path)) return "sales";
  if (/shareActive=true/i.test(query) || /\/preload/i.test(path)) return "compose";
  if (/^\/jobs/i.test(path)) return "jobs";
  if (/^\/mynetwork/i.test(path)) return "network";
  if (/^\/feed/i.test(path) || /^\/hp/i.test(path)) return "feed";
  if (path === "/" || path === "") return "home";
  return "other";
}

function sanityGuessIntent(kind) {
  if (kind === "messaging") return "inbox";
  if (kind === "notifications") return "notifications";
  if (kind === "search" || kind === "profile" || kind === "company" || kind === "sales") {
    return "research";
  }
  if (kind === "compose") return "publish";
  if (kind === "feed") return "scroll";
  return null;
}

function sanityPathAllowed(state, kind) {
  if (kind === "auth") return true;
  const intent = sanityIntent(state.session && state.session.intent);
  if (!intent) return false;
  return intent.allow.includes(kind);
}

function sanityRemainingMs(state, now = Date.now()) {
  if (!sanityIsSessionActive(state, now)) return 0;
  return Math.max(0, state.session.endsAt - now);
}

function sanityFormatClock(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function sanityFormatLogWhen(timestamp) {
  return new Date(timestamp).toLocaleString([], {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function sanityIsLinkedInHost(hostname = "") {
  const host = String(hostname).toLowerCase();
  return host === "linkedin.com" || host.endsWith(".linkedin.com");
}

function sanityIsLinkedInUrl(url = "") {
  try {
    return sanityIsLinkedInHost(new URL(url).hostname);
  } catch (_error) {
    return false;
  }
}

function sanityCloseSession(state, reason = "manual") {
  if (!state.session) return null;
  const now = Date.now();
  const startedAt = state.session.startedAt;
  const actualMs = Math.max(0, now - startedAt);
  const actualMinutes = Math.max(1, Math.ceil(actualMs / 60000));
  const requestedMinutes = Number(state.session.requestedMinutes) || Math.round(state.session.durationMs / 60000);
  const intent = sanityIntent(state.session.intent);
  const entry = {
    id: `${startedAt}-${Math.random().toString(36).slice(2, 8)}`,
    date: sanityTodayKey(),
    intent: state.session.intent,
    label: intent ? intent.label : state.session.intent,
    requestedMinutes,
    actualMinutes,
    startedAt,
    endedAt: now,
    reason,
  };
  state.usage.minutes = Math.min(
    state.settings.dailyBudgetMinutes,
    state.usage.minutes + actualMinutes
  );
  state.log = [entry, ...(state.log || [])].slice(0, SANITY_LOG_LIMIT);
  state.lastLog = entry;
  state.lastIntent = state.session.intent;
  state.session = null;
  return entry;
}
