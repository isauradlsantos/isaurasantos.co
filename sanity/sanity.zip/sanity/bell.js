function sanityPlayBell() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const duration = 2.4;

    // Soft low-pass keeps the strike smooth, never brittle
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(2400, now);
    filter.Q.setValueAtTime(0.5, now);

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.linearRampToValueAtTime(0.14, now + 0.04);
    master.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    filter.connect(master);
    master.connect(ctx.destination);

    // Minimal premium chime: one calm fundamental + a whisper of octave
    const tones = [
      { freq: 659.25, peak: 0.55, attack: 0.045 }, // E5 — soft, centered
      { freq: 1318.5, peak: 0.08, attack: 0.03 }, // E6 — faint sparkle only
    ];

    tones.forEach(({ freq, peak, attack }) => {
      const osc = ctx.createOscillator();
      const amp = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, now);
      amp.gain.setValueAtTime(0.0001, now);
      amp.gain.linearRampToValueAtTime(peak, now + attack);
      amp.gain.exponentialRampToValueAtTime(0.0001, now + duration);
      osc.connect(amp);
      amp.connect(filter);
      osc.start(now);
      osc.stop(now + duration + 0.05);
    });

    setTimeout(() => {
      ctx.close().catch(() => {});
    }, Math.ceil(duration * 1000) + 200);
  } catch (_error) {
    /* audio unavailable */
  }
}
